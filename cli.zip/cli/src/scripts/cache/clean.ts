import {removeCache} from './cache';

removeCache();
