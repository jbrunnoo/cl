import {syncDocs} from '.';

syncDocs();
