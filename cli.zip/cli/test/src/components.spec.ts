import {describe, expect, test} from 'vitest';

describe('components', () => {
  test('UpdateComponents function ', () => {
    // TODO: wait for the canary option merged to finish this test
    expect(1).toBe(1);
  });
});
