# Instalação Local do BlingUI CLI

Este guia explica como instalar e testar o BlingUI CLI localmente durante o desenvolvimento.

## Pré-requisitos

- Node.js 18.17.x ou superior
- pnpm 9.x ou superior

## Passo a Passo

### 1. Instalar dependências

```bash
pnpm install
```

### 2. Build do projeto

Compile o projeto TypeScript para JavaScript:

```bash
pnpm build
```

Isso irá:
- Compilar o código TypeScript para `dist/`
- Gerar os arquivos `.d.ts` (tipos TypeScript)
- Copiar arquivos necessários (como `components.json`)

### 3. Configurar pnpm (se necessário)

Se você receber o erro `ERR_PNPM_NO_GLOBAL_BIN_DIR`, configure o pnpm primeiro:

```bash
pnpm setup
```

Isso irá:
- Criar o diretório global do pnpm
- Adicionar ao PATH automaticamente
- Configurar as variáveis de ambiente necessárias

**Após executar `pnpm setup`, você precisará:**
1. Recarregar o terminal (fechar e abrir novamente)
2. Ou executar: `source ~/.zshrc` (ou `source ~/.bashrc` se usar bash)

### 4. Link global (instalação local)

Crie um link simbólico global para testar o CLI:

```bash
pnpm run link:cli
```

Ou manualmente:

```bash
pnpm link --global
```

Isso criará um link global do comando `bling` apontando para o seu projeto local.

### 5. Verificar instalação

Teste se o comando está funcionando:

```bash
bling --version
bling --help
```

### 6. Desenvolvimento com watch

Para desenvolvimento com hot-reload, use:

```bash
pnpm dev
```

Isso irá:
- Compilar o código em modo watch
- Recompilar automaticamente quando você fizer mudanças
- Você precisará reiniciar o comando `bling` para ver as mudanças

**Nota:** O modo watch não recarrega automaticamente o comando global. Após mudanças, você pode precisar executar `bling` novamente.

### 7. Remover link global

Quando quiser remover o link global:

```bash
pnpm run link:remove
```

Ou manualmente:

```bash
pnpm uninstall --global blingui-cli
```

## Fluxo de Desenvolvimento Recomendado

1. **Terminal 1** - Modo watch:
   ```bash
   pnpm dev
   ```

2. **Terminal 2** - Testar comandos:
   ```bash
   # Após fazer mudanças e o build completar
   bling --help
   bling add button
   ```

## Troubleshooting

### Erro: Unable to find the global bin directory

Se você receber este erro ao tentar fazer `pnpm link --global`:

```
ERR_PNPM_NO_GLOBAL_BIN_DIR  Unable to find the global bin directory
```

**Solução:**

1. Execute o setup do pnpm:
   ```bash
   pnpm setup
   ```

2. Recarregue o terminal:
   ```bash
   # Para zsh (padrão no macOS)
   source ~/.zshrc
   
   # Ou para bash
   source ~/.bashrc
   ```

3. Verifique se o PATH foi atualizado:
   ```bash
   echo $PATH | grep pnpm
   ```

4. Tente novamente:
   ```bash
   pnpm link --global
   ```

**Alternativa:** Se ainda não funcionar, você pode usar `npm link` em vez de `pnpm link --global`:

```bash
npm link
```

### Comando não encontrado

Se o comando `bling` não for encontrado após o link:

1. Verifique se o build foi feito:
   ```bash
   ls dist/index.js
   ```

2. Verifique o PATH do Node.js:
   ```bash
   echo $PATH
   # Deve incluir o diretório global do pnpm/npm
   ```

3. Tente reinstalar o link:
   ```bash
   pnpm run link:remove
   pnpm run link:cli
   ```

### Mudanças não aparecem

1. Certifique-se de que o build foi executado:
   ```bash
   pnpm build
   ```

2. Se estiver usando `pnpm dev`, aguarde a recompilação

3. Execute o comando novamente

### Erro de permissão

Se houver erro de permissão ao fazer o link global:

```bash
# No macOS/Linux, pode precisar de sudo (não recomendado)
# Melhor: configurar npm/pnpm para não usar sudo
```

## Estrutura do Build

Após o build, a estrutura será:

```
dist/
  ├── index.js          # Arquivo principal do CLI
  ├── index.d.ts        # Tipos TypeScript
  └── components.json   # Dados dos componentes (copiado automaticamente)
```

## Próximos Passos

Após a instalação local funcionando:

1. Teste todos os comandos principais
2. Faça ajustes nas funcionalidades
3. Atualize as referências aos pacotes npm quando necessário
4. Teste em um projeto real

