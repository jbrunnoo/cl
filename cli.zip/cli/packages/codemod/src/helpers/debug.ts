export const DEBUG = {
  enabled: false
};
